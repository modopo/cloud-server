# AWS

## Beanstalk

* Deployed manually through GUI using a single zip file

* Deployed through `eb deploy` CLI methods
  * Adding another route to verify successfull deployment
